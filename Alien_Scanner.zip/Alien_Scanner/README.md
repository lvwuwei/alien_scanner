# Alien_Scanner
Alien_Scanner - Pentest the Modern Web

Author: [MR.X]>>Bangladesh Syber Pro

Disclaimer: I am not responsible for any damage done using this tool. This tool should only be used for educational purposes and for penetration testing.

###Compatibility:
* Any platform using Python 2.7

###Requirements:
* Python 2.7
* Modules(included): Colorama, BeautifulSoup

###Description:
**Alien_Scanner** is an All-In-One Tool for Penetration Testing. This is specially programmed for Penetration Testers and Security Researchers to make their job easier, instead of launching different tools for performing different task. **Alien_Scanner** provides multiple features and detection features which gather target information and finds different flaws in it. 

###Features:
# Sub-domain Scanning
# Port Scanning
# Wordpress Scanning
# Wordpress Username Enumeration
# Wordpress Backup Grabbing
# Sensitive File Detection
# Same-Site Scripting Scanning
# Click Jacking Detection
# Powerful XSS vulnerability scanning
# SQL Injection vulnerability scanning
# User-Friendly UI


